package com.example.blogsystem.controller;

import com.example.blogsystem.common.Result;
import com.example.blogsystem.entity.User;
import com.example.blogsystem.mapper.UserMapper;
import com.example.blogsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
@RestController
//@CrossOrigin(originPatterns = )
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserMapper userMapper;

    @GetMapping("findAll")
    public List<User> index(){
        return userMapper.findAll();
    }

    //    @GetMapping
    @GetMapping("login")
    public Result<String> login(@RequestParam("userPhone") String userPhone, @RequestParam("userPass") String userPass){
        String Message="登录失败";
        int code=-1;
        List<User> user=userMapper.login(userPhone,userPass);
        if (user.size()>0){
            Message="登录成功";
            code=200;
        }
        return new Result(code,Message,"");
    }
    @PostMapping("add")
    public Result<User> register(@RequestBody User user){
       System.out.println(user.toString());
        int code=-1;
        List<User> user1=userMapper.findUserByPhone(user);
        if (user1.size()== 0){
            code=200;
            userMapper.res(user.getUserName(),user.getUserPass(),user.getUserPhone());
            return new Result(code,"注册成功",null);
        }
        return new Result(code,"注册失败",null);
    }

    @PostMapping("delete")
    public Result<Integer> deleteUserById(@RequestBody User user){
        Integer result=userMapper.deleteById(user);
        if (result>0){
            return new Result(200,"删除成功","");
        }

        return new Result(-1,"删除失败","");
    }
    @PostMapping("update")
    public Result<String> updateUser(@RequestBody User user){

        int result= userMapper.updateUser(user);
        if (result>0){
            return new Result(200,"更新成功",user);
        }else {
            return new Result(-1,"更新失败",user);
        }

    }
    //分页查询
    @GetMapping("page")
    public Result<HashMap> paginUsers(@RequestParam("username")String username,@RequestParam("pageNum")Integer pageNum, @RequestParam("pageSize")Integer pageSize) {
        //获取总条数
        Integer count = userMapper.userTotalCount(username);
        //分页查询
        //将pageNum进行转换，pageNum,第几页，但数据库limit是要的开始查询的位置
        pageNum = (pageNum - 1) * pageSize;
        List<User> list =userMapper.paginUsers(username,pageNum,pageSize);
        //用HashMap保存总条数以及查询结果
        HashMap<String,Object> map =new HashMap();
        map.put("count",count);
        map.put("list",list);
        return new Result(200,"查询成功",map);
    }

}
